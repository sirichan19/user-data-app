import { saveUserDataToDynamoDB } from "./adapters/db/userDatadb";
import { User, UserData } from "./types/user";

export const handler = async (event: UserData): Promise<[number, string][] | void> => {

    let validUsers: User[] = [];
    let invalidUserData: [number, string][] = []; // array of tuples
    for (const user of event.users) {
        if (user.name === null || user.name === undefined) {
            invalidUserData.push([user.id, "name is undefined"]);
        }

        if (!isValidEmail(user.email)) {
            invalidUserData.push([user.id, "email is invalid"]);
        }

        if (user.age >= 18 && user.age <= 100) {
            invalidUserData.push([user.id, "age is invalid"]);
        }
        if (invalidUserData.length !== 0) {
            return invalidUserData;
        }
        validUsers.push(user);
        if (validUsers.length > 0) {
            try {
                for(const user of validUsers){
                await saveUserDataToDynamoDB(user);
                }
            }
            catch (err) {
                console.log("unable to save data to dynamoDB", err);
            }
        }
    }
}

const isValidEmail = (email: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}


