type UserResponse = {
    id  : number;   
    name : string;
    email : string;
    age : number;    
}